package elico.com;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button button_help;
    private Button button_calculate;
    private EditText editText_weight;
    private EditText editText_height;
    private TextView textView_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
        set_BMI_Calculate(button_calculate, editText_weight, editText_height);
        button_help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("Help")
                        .setMessage("世界衛生組織建議以身體質量指數（Body Mass Index, BMI）來衡量肥胖程度，其計算公式是以體重（公斤）除以身高（公尺）的平方。\n國民健康署建議我國成人BMI應維持在18.5（kg/m2）及24（kg/m2）之間，太瘦、過重或太胖皆有礙健康。\n研究顯示，體重過重或是肥胖（BMI≧24）為糖尿病、心血管疾病、惡性腫瘤等慢性疾病的主要風險因素；而過瘦的健康問題，則會有營養不良、骨質疏鬆、猝死等健康問題。")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                editText_height.setText("");
                                editText_weight.setText("");
                            }
                        })
                        .show();
            }
        });
    }

    private void initialize() {
        button_help = findViewById(R.id.button_Help);
        button_calculate = findViewById(R.id.button_Sent);
        editText_weight = findViewById(R.id.editText_Weight);
        editText_height = findViewById(R.id.editText_Height);
        textView_result = findViewById(R.id.textView_Result);
    }

    private void set_BMI_Calculate(Button button_Calculate, EditText editText_Weight, EditText editText_Height) {
        button_Calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float weight = Float.valueOf(editText_Weight.getText().toString());
                float height = Float.valueOf(editText_Height.getText().toString());
                if (height > 4 || height < 0)
                {
                    Toast.makeText(MainActivity.this,"身高是以公尺為單位",Toast.LENGTH_SHORT).show();
                    return;
                }
                if (weight > 300 || weight < 0)
                {
                    Toast.makeText(MainActivity.this,"體重限制300~0之間",Toast.LENGTH_SHORT).show();
                    return;
                }
                float result = weight / (height * height);
                String saySomething = null;
                if (result < 18.5)
                    saySomething = "體重過輕";
                else if (result >= 24 && result < 27)
                    saySomething = "體重過重";
                else if (result >= 27 && result < 30)
                    saySomething = "輕度肥胖";
                else if (result >= 30 && result < 35)
                    saySomething = "中度肥胖";
                else if (result >= 35)
                    saySomething = "重度肥胖";
                else
                    saySomething = "正常";
                //第三種顯示方法
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle(saySomething);
                builder.setMessage("Your BMI is: " + result);
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        editText_Height.setText("");
                        editText_Weight.setText("");
                    }
                });
                builder.show();
                //第一種顯示方法
                textView_result.setText(saySomething + "\t" + "BMI: " + String.valueOf(result));
                //第二種顯示方法
                Toast.makeText(MainActivity.this,saySomething + "\t" + String.valueOf(result),Toast.LENGTH_SHORT).show();
            }
        });
    }
}