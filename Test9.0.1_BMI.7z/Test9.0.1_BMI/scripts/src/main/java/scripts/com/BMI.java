package scripts.com;

public class BMI {
    public float Calculate(float weight,float height){
        return weight / (height * height);
    }
}